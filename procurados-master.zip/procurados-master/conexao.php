<?php 
$conn = new MySqli("localhost", "root", "", "loginproc");
?>